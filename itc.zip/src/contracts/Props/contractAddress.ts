export const contractAddress = "0x46192b218ad664be173535b413F0928C0aEc50E9";
export default contractAddress;
