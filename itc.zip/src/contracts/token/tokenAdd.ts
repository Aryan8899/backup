export const tokenAdd = "0xa2A881162C0f1a8C95d0F45B3DF0cb4296a58403"
export default tokenAdd;