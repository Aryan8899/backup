import rank0 from "./images/rank0.png";
import rank1 from "./images/rank1.png";
import rank2 from "./images/rank2.png";
import rank3 from "./images/rank3.png";
import rank4 from "./images/rank4.png";
import rank5 from "./images/rank5.png";
import rank6 from "./images/rank6.png";
import rank7 from "./images/rank7.png";
import rank8 from "./images/rank8.png";
import robotImage from "./images/robot.png";

export {
  rank0,
  rank1,
  rank2,
  rank3,
  rank4,
  rank5,
  rank6,
  rank7,
  rank8,
  robotImage,
};
